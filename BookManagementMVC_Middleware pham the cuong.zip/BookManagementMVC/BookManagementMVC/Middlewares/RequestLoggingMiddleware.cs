using System.Diagnostics;

namespace BookManagementMVC.Middlewares;

public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;

    public RequestLoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var stopwatch = Stopwatch.StartNew();
        var time = DateTime.Now;
        var method = context.Request.Method;
        var path = context.Request.Path.ToString();

        Console.WriteLine($"[{time:yyyy-MM-dd HH:mm:ss.fff}] Method: {method} - Path: {path}");

        if (path.Equals("/Book/Detail/0", StringComparison.OrdinalIgnoreCase) ||
            path.Equals("/Book/Detail/-1", StringComparison.OrdinalIgnoreCase))
        {
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            await context.Response.WriteAsync("Book id khong hop le");

            stopwatch.Stop();
            Console.WriteLine($"Status Code: {context.Response.StatusCode} - {stopwatch.Elapsed.TotalMilliseconds:F2} ms");
            return;
        }

        await _next(context);

        stopwatch.Stop();
        Console.WriteLine($"Status Code: {context.Response.StatusCode} - {stopwatch.Elapsed.TotalMilliseconds:F2} ms");
    }
}
